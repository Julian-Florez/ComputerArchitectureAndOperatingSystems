def facto_i(num):
    c = 1
    for i in range(1, num + 1):
        c *= i
    return c